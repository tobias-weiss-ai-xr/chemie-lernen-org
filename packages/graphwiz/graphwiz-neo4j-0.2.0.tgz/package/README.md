# @graphwiz/neo4j

Neo4j client with dependency injection. Wraps the official `neo4j-driver` with a clean class-based API for queries, health checks, and connection management.

## Installation

```bash
npm install @graphwiz/neo4j
```

Requires `neo4j-driver` (^5.27.0) as a peer dependency.

## Usage

### Neo4jClient (recommended)

Accepts either a `neo4j.Driver` instance (for DI/testing) or a `Neo4jConfig` object.

```ts
import { Neo4jClient } from '@graphwiz/neo4j';

const client = new Neo4jClient({
  uri: 'bolt://localhost:7687',
  username: 'neo4j',
  password: 's3cret',
});

const rows = await client.query('MATCH (n:Person) RETURN n LIMIT 10');
// rows: Neo4jRow[]

const health = await client.healthCheck();
// { status: 'connected', version: '5.21.0', latencyMs: 3 }

await client.close();
```

### Testing with a mock driver

```ts
import { Neo4jClient } from '@graphwiz/neo4j';
import neo4j from 'neo4j-driver';

const driver = neo4j.driver('bolt://localhost', neo4j.auth.basic('u', 'p'));
const client = new Neo4jClient(driver);  // client won't close the driver
```

### Legacy API (deprecated)

Module-level singleton functions are preserved for backward compatibility:

```ts
import { createDriver, runQuery, healthCheck, closeDriver } from '@graphwiz/neo4j';

const config = { uri: 'bolt://localhost:7687', username: 'neo4j', password: 's3cret' };
const rows = await runQuery(config, 'MATCH (n) RETURN n LIMIT 10');
```

## API

| Method | Description |
|--------|-------------|
| `query(cypher, params?)` | Run a Cypher query, returns rows as plain objects |
| `healthCheck()` | Check server connectivity and latency |
| `close()` | Close the underlying driver (only if owned) |

## License

MIT
