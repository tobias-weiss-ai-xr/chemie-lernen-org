# @graphwiz/builder

Co-occurrence graph builder. Builds `GraphData` from tagged documents or entity-annotated articles — finds co-occurring labels and constructs nodes + weighted edges.

## Installation

```bash
npm install @graphwiz/builder
```

Depends on `@graphwiz/core` for `GraphData` types.

## Usage

### From tags

```ts
import { buildTagGraph } from '@graphwiz/builder';

const graph = buildTagGraph([
  { id: 'doc-1', title: 'Introduction to Graph Theory', tags: ['graphs', 'math', 'algorithms'] },
  { id: 'doc-2', title: 'Neo4j in Production', tags: ['neo4j', 'graphs', 'database'] },
], { minCoOccurrence: 2 });

// graph.nodes — GraphNode[] (including article nodes + tag nodes)
// graph.edges — GraphEdge[] (weighted co-occurrence edges between tags)
```

### From entities

```ts
import { buildEntityGraph } from '@graphwiz/builder';

const graph = buildEntityGraph([
  { title: 'Article 1', url: 'https://...', entities: ['TypeScript', 'GraphQL'] },
  { title: 'Article 2', url: 'https://...', entities: ['TypeScript', 'Neo4j'] },
], { minCoOccurrence: 1 });
```

## Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `minCoOccurrence` | `number` | `1` | Minimum co-occurrence count to create an edge |
| `relationshipType` | `string` | `'RELATED_TO'` | Label for generated edges |
| `includeSingletons` | `boolean` | `true` | Include nodes with no edges |

## API

| Function | Description |
|----------|-------------|
| `buildTagGraph(documents, options?)` | Build graph from `{ id, title, tags, url? }[]` |
| `buildEntityGraph(articles, options?)` | Build graph from `{ title, url, entities, tags? }[]` |

## License

MIT
