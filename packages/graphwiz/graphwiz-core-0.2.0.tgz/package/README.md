# @graphwiz/core

Core TypeScript types and interfaces for the graph-wiz ecosystem. Framework-agnostic — every package in the monorepo builds on these types.

## Installation

```bash
npm install @graphwiz/core
```

## Types

| Type | Description |
|------|-------------|
| `GraphNode` | Node with `id`, `label`, `type`, optional `category`/`weight`/`metadata` |
| `GraphEdge` | Edge with `source`, `target`, optional `label`/`weight`/`relationship`/`metadata` |
| `GraphData` | Container with `nodes: GraphNode[]`, `edges: GraphEdge[]`, optional `metadata` |

**Neo4j types:**

| Type | Description |
|------|-------------|
| `Neo4jConfig` | Connection config (`uri`, `username`, `password`, optional `database`) |
| `Neo4jRow` | Generic query result row (`Record<string, unknown>`) |
| `Neo4jHealth` | Health check result with `status`, `version`, `latencyMs` |

**Co-occurrence types:**

| Type | Description |
|------|-------------|
| `CoOccurrenceOptions` | `minCoOccurrence`, `relationshipType`, `includeSingletons` |
| `CoOccurrencePair` | Pair with `source`, `target`, `weight` |

**GDS types:**

| Type | Description |
|------|-------------|
| `GdsAlgorithmConfig` | Base config (`concurrency`, `nodeLabels`, `relationshipTypes`) |
| `GdsStreamResult` | Generic stream result (`nodeId`, `score`, `communityId`) |
| `GdsStatsResult` | Stats result with timing fields |
| `GdsMutateResult` | Mutate mode result (extends `GdsStatsResult`) |
| `GdsWriteResult` | Write mode result (extends `GdsStatsResult`) |
| `GdsSimilarityResult` | Similarity pair (`node1`, `node2`, `similarity`) |
| `GdsWccResult` | WCC result (`nodeId`, `componentId`) |
| `GdsPathResult` | Path result (`sourceNode`, `targetNode`, `totalCost`, `nodeIds`, `costs`) |

## Usage

```ts
import type { GraphNode, GraphEdge, GraphData } from '@graphwiz/core';

const graph: GraphData = {
  nodes: [
    { id: '1', label: 'Node A', type: 'concept' },
    { id: '2', label: 'Node B', type: 'concept' },
  ],
  edges: [
    { source: '1', target: '2', label: 'related', weight: 5 },
  ],
};
```

## License

MIT
